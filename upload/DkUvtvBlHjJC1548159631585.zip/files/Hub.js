var express = require("express");
var app = express();
var bodyParser = require("body-parser");
var cookieParser = require("cookie-parser");
var session = require("express-session");

var mysql = require("mysql");
var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "noumena",
  database: "College"
});

connection.connect();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(session({ secret: "jhfhfuf" }));

var path = require("path");
app.use(express.static("task"));
app.set("view engine", "ejs");

//college//

app.get("/", function(req, res) {
  res.redirect("/colleges");
});
app.get("/colleges", function(req, res) {
  getcolleges(function(results) {
    res.render("pages/colleges", { results_clg: results });
  });
});

app.post("/colleges", function(req, res) {
  console.log(req.body);
  var post1 = {
    college_name: req.body.college_name,
    Address: req.body.Address
  };
  var query = connection.query("INSERT INTO Info1 SET ?", post1, function(
    error,
    results,
    fields
  ) {
    if (error) throw error;
    res.send("Submited");
  });
});

app.put("/colleges", function(req, res) {
  console.log(req.body);
  var college_id = req.body.college_id;
  var post1 = {
    college_name: req.body.college_name,
    Address: req.body.Address
  };

  var query = connection.query(
    "UPDATE Info1 SET ? WHERE ?",
    [post1, { college_id: college_id }],
    function(error, results, fields) {
      if (error) throw error;
      res.send("Submited");
    }
  );
});
app.get("/colleges/:college_id", function(req, res) {
  console.log(req.params.course_id);
  var query = connection.query(
    "SELECT * FROM Info1 WHERE college_id=?",
    [req.params.college_id],
    function(error, results, feilds) {
      if (error) throw error;
      let college = {};
      if(results.length > 0) {
        // console.log(results,results.length);
        college = results[0];
      }
      res.json({ college: college });
    }
  );
});

app.delete("/colleges/:college_id", function(req, res) {
  console.log(req.params.college_id);
  var query = connection.query(
    "DELETE FROM Info1 WHERE college_id=?",
    [req.params.college_id],
    function(error, results, feilds) {
      if (error) throw error;
      res.json({ success: "Submitted" });
    }
  );
});

//course//
app.get("/courses", function(req, res) {
  getcourses(function(results) {
    res.render("pages/courses", { result_courses: results });
  });
});

app.get("/courses/:course_id", function(req, res) {
  console.log(req.params.course_id);
  var query = connection.query(
    "SELECT * FROM courses WHERE id=?",
    [req.params.course_id],
    function(error, results, feilds) {
      if (error) throw error;
      let course = {};
      if(results.length > 0) {
        course = results[0];
      }
      res.json({ course: course });
    }
  );
});

app.post("/courses", function(req, res) {
  console.log(req.body);
  var post2 = {
    course: req.body.course
  };
  var query = connection.query("INSERT INTO courses SET ?", post2, function(
    error,
    results,
    fields
  ) {
    if (error) throw error;
    res.send("Submitted");
  });
});




app.put("/courses", function(req, res) {
  console.log(req.body);
  var course_id = req.body.id;
  var post2 = {
    course: req.body.course,
  };

  var query = connection.query(
    "UPDATE courses SET ? WHERE ?",
    [post2, {id:course_id }],
    function(error, results, fields) {
      if (error) throw error;
      res.send("Submited");
    }
  );
});




app.delete("/courses/:course_id", function(req, res) {
  console.log(req.params.course_id);
  var query = connection.query(
    "DELETE FROM courses WHERE id=?",
    [req.params.course_id],
    function(error, results, feilds) {
      if (error) throw error;
      res.json({ success: "Submitted" });
    }
  );
});

//student//
app.get("/students", function(req, res) {
  getcolleges(function(colleges) {
    getcourses(function(courses) {
      getstudents(function(results) {
        res.render("pages/students", {
          results_stud: results,
          colleges: colleges,
          courses: courses
        });
      });
    });
  });
});



app.get("/students/:student_id", function(req, res) {
  console.log(req.params.student_id);
  var query = connection.query(
    "SELECT * FROM students WHERE id=?",
    [req.params.student_id],
    function(error, results, feilds) {
      if (error) throw error;
      let student = {};
      if(results.length > 0) {
                student = results[0];
      }
      res.json({ student: student });
      console.log(student);
    }
  );
});



app.post("/students", function(req, res) {
  console.log(req.body);
  var post3 = {
    student_name: req.body.student_name,
    email_id: req.body.email_id,
    college_id: req.body.college_id,
    course_id: req.body.course_id,
    mobile_no: req.body.mobile_no
  };

  var query = connection.query("INSERT INTO students SET ?", post3, function(
    error,
    results,
    feilds
  ) {
    if (error) throw error;
    res.send("Submitted");
  });
});



app.put("/students", function(req, res) {
  console.log(req.body);
  var student_id = req.body.student_id;
  var post3 = {
    student_name: req.body.student_name,
    email_id: req.body.email_id,
    college_id: req.body.college_id,
    course_id: req.body.course_id,
    mobile_no: req.body.mobile_no
  };

  var query = connection.query(
    "UPDATE students SET ? WHERE ?",
    [post3, {id:student_id }],
    function(error, results, fields) {
      if (error) throw error;
      res.send("Submitted");
    }
  );
});




app.delete("/students/:student_id", function(req, res) {
  console.log(req.params.student_id);
  var query = connection.query(
    "DELETE FROM students WHERE id=?",
    [req.params.student_id],
    function(error, results, feilds) {
      if (error) throw error;
      res.json({ success: "Submitted" });
    }
  );
});
app.listen(3000, function() {
  console.log("created!!!");
});

function getcolleges(callback) {
  var query = connection.query("SELECT * FROM Info1", function(error, data) {
    if (error) throw error;
    callback(data);
  });
}
function getcourses(callback) {
  var query = connection.query("SELECT * FROM courses", function(error, data1) {
    if (error) throw error;
    callback(data1);
  });
}
function getstudents(callback) {
  var query = connection.query(
    "SELECT students.*,Info1.college_name,courses.course  FROM students LEFT JOIN Info1 ON (students.college_id=Info1.college_id) LEFT JOIN courses ON (students.course_id=courses.id)ORDER BY student_name",
    function(error, data3) {
      if (error) throw error;
      callback(data3);
    }
  );
}
