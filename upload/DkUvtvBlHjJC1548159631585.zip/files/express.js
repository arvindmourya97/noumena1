var express = require("express");
var app = express();
var bodyParser = require("body-parser");
var cookieParser = require("cookie-parser");
var session = require("express-session");

var mysql = require("mysql");
var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "noumena",
  database: "a1"
});

connection.connect();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(session({ secret: "SDFSSDWRWERSFTE" }));

var path = require("path");
app.use(express.static("public"));
app.set("view engine", "ejs");

app.get("/", function(req, res) {
  res.redirect("/form1");
});

app.get("/form1", function(req, res) {
  res.render("pages/form1");
});

app.post("/form1", function(req, res) {
  console.log(req.body);
  req.session.user_data = {
    name: req.body.name,
    contact_no: req.body.number,
    email: req.body.email,
    City: req.body.City,
    College: req.body.College,
    Course: req.body.Course,
    Year_Of_Study: req.body.Year_Of_Study
  };

  res.redirect("/form2");
});

app.get("/form2", function(req, res) {
  console.log(req.session.user_data);

  res.render("pages/form2");
});

app.post("/form2", function(req, res) {
  var post = {
    name: req.session.user_data.name,
    contact_no: req.session.user_data.contact_no,
    email: req.session.user_data.email,
    City: req.session.user_data.City,
    College: req.session.user_data.College,
    Course: req.session.user_data.Course,
    Year_Of_Study: req.session.user_data.Year_Of_Study
    // opt1: req.body.optradio1,
    // opt2: req.body.optradio2
  };

  var query = connection.query("INSERT INTO test1 SET ?", post, function(
    error,
    results,
    fields
  ) {
    if (error) throw error;
    res.send("Submited");
  });
});
app.post("/form3", function(req, res) {
  var post1 = {
    opt1: req.body.optradio1,
    opt2: req.body.optradio2,
    opt3: req.body.optradio3,
    opt4: req.body.optradio4,
    opt5: req.body.optradio5,
    opt6: req.body.optradio6,
    opt7: req.body.optradio7,
    opt8: req.body.optradio8,
    opt9: req.body.optradio9,
    opt10: req.body.optradio10
  };
  var query = connection.query("INSERT INTO test2 SET ?", post1, function(
    error,
    results,
    fields
  ) {
    if (error) throw error;
    res.send("Submited");
  });
});

app.get("/listing", function(req, res) {
  var query = connection.query("SELECT * FROM test1", function(error, results) {
    if (error) throw error;
    console.log(results);
    res.render("pages/listing", { results1: results, name: "prashant" });
  });
});

app.listen(3000, function() {
  console.log("created!!!");
});
